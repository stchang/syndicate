 - Some way of adjusting target frame rate based on whether we're
   achieving the goal or not; e.g. fall back from 60Hz to 24Hz

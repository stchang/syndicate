"use strict";
// $Special: Builder of singleton "atoms".

function $Special(name) {
  this.name = name;
}

module.exports = $Special;

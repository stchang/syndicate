# Syndicate/js compiler

Translates ES5 + Syndicate extensions to plain ES5 using
[Ohm](https://github.com/cdglabs/ohm#readme).

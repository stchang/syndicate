# Operational Transformation

The program `syndicate-server.rkt` is a port of
[`server.rkt`](https://github.com/tonyg/racket-operational-transformation/blob/master/operational-transformation-demo/server.rkt)
to Syndicate.

It accepts the same command-line arguments, and works with unmodified
[clients](https://github.com/tonyg/racket-operational-transformation/blob/master/operational-transformation-demo/client.rkt);
see the
[README](https://github.com/tonyg/racket-operational-transformation/blob/master/README.md)
for more information.

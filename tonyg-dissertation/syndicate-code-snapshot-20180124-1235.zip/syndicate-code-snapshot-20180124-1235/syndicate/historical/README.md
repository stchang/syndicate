# Historical implementations of Syndicate and its predecessors

 - `syndicate-monolithic` is an implementation of the "monolithic
   state change notification" dialect of Syndicate for Racket.

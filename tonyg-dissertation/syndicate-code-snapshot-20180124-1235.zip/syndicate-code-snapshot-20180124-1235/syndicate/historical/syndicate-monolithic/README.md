# syndicate-monolithic

This is an implementation of the monolithic semantics, without any use
of patches.

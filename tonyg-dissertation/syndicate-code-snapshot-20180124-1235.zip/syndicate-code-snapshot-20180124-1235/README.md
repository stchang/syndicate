# Source code snapshot

This archive contains source code and example programs for Syndicate,
the actor-based programming language I developed as part of my PhD
work.

The latest version of this archive is available at
<http://syndicate-lang.org/tonyg-dissertation/> along with the
dissertation itself, a recording of my dissertation defense talk, the
slides I used for my talk, and the proof scripts accompanying the
dissertation.

Please see <http://syndicate-lang.org/> for information about
Syndicate in general.

— Tony Garnock-Jones tonyg@leastfixedpoint.com

## Racket

You will need Racket version 6.11 or newer to run the included Racket
programs.

## Contents

The central part of the archive is the `syndicate` directory:

 - `syndicate`:
     - The Racket and Javascript implementations of the language.
     - Many, many small example programs
     - Larger example programs: an IRC server; a TCP/IP protocol
       stack; an operational-transformation server; a 2D
       platform-style game; a WhatsApp-like web-based chat application

Also included are a few Syndicate-based applications, tools, and
experiments not included in the main source repository:

 - `marketplace-dns`: Recursive DNS resolver
 - `racketmq`: [WebSub](https://www.w3.org/TR/websub/) server
 - `syndicate-os`: Steps toward a Syndicate-based GUI toolkit and desktop
 - `syndicate-broker-daemontools`: Daemontools drivers for running a Syndicate broker
 - `treetrie`: Experimental C-based implementation of the trie data structure described in my dissertation

Finally, portions of the code depend on other Racket libraries:

 - `racket-auxiliary-macro-context`
 - `racket-bitsyntax`
 - `racket-operational-transformation`
 - `racket-packet-socket`
 - `racket-rfc6455`
 - `racket-struct-defaults`
 - `racket-unix-signals`
